<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
  <?php wp_head(); ?>
</head>
<body>
  <header class="header" >
    <img src="<?php bloginfo('template_url')?>/img/header_bckgr.jpg" alt="" class="slider-box" id="slider">
    <div class="header-container">
      <div class="head clearfix">
        <nav class="header-nav">
          <?php wp_nav_menu(array('theme_location' => 'menu', 'menu_class' => 'nav-list', 'container' => 'false')); ?>
        </nav>
        <div class="logo">Logo</div>
      </div>
      <h1 class="header-title"><?php bloginfo('name')?>, <?php echo get_theme_mod('header_slogan', 'what you need to know'); ?></h1>
      <div class="head-content clearfix">
        <div class="content-col left">
          <h2><?php echo get_theme_mod('left-col-subhead', 'What’s in the lorem?'); ?></h2>
          <p><?php echo get_theme_mod('left-col-para1', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque est excepturi magnam optio, possimus quaerat quasi,'); ?></p>
          <p><?php echo get_theme_mod('left-col-para2', 'quibusdam recusandae rem repellendus rerum sapiente? Amet distinctio doloribus fugiat nesciunt quos, recusandae vel.'); ?></p>
        </div>
        <div class="content-col right">
          <h2><?php echo get_theme_mod('right-col-subhead', 'Get your free copy'); ?></h2>
          <div class="form">
            <form class="get-copy" action="#" method="post">
              <div class="info">
                <label>Name:
                  <input type="text" name="name" value="" placeholder="Please leave your name" required="required" pattern="[a-zA-Z0-9]+">
                </label>
                <label> E-mail:
                  <input type="email" name="email" value="" placeholder="Please leave your e-mail" required="required">
                </label>
                <label>
                  <input type="submit" name="create" value="<?php echo get_theme_mod('head-btn-text', 'GET THE BOOK'); ?>">
                </label>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </header>
