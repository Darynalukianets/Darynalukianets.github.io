<footer>
  <div class="footer-container">
    <button class="footer-btn"><?php echo get_theme_mod('footer-btn', 'i want to read!'); ?></button>
    <p class="ask"><?php echo get_theme_mod('footer-text', 'Have questions?'); ?><a href=""><?php echo get_theme_mod('footer-link', 'Ask away'); ?></a></p>
    <div class="share">
      <a href="" class="share-link fb">Share</a>
      <a href="" class="share-link twit">Tweet</a>
    </div>
    <p class="copyright">&copy;<?php echo get_theme_mod('copyright', ' Lorem 2015'); ?></p>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
