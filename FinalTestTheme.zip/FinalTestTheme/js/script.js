var dataJson = [
  {
    "id": 1,
    "ﬁrst_name": "Jonathan",
    "last_name": "Mendoza",
    "email": "jmendoza0@posterous.com",
    "gender": "Male"
  },
  {
    "id": 2,
    "ﬁrst_name": "Sandra",
    "last_name": "Payne",
    "email": "spayne1@unc.edu",
    "gender": "Female"
  },
  {
    "id": 3,
    "ﬁrst_name": "Denise",
    "last_name": "Rodriguez",
    "email": "drodriguez2@slashdot.org",
    "gender": "Female"
  },
  {
    "id": 4,
    "ﬁrst_name": "Irene",
    "last_name": "Armstrong",
    "email": "iarmstrong3@blogspot.com",
    "gender": "Female"
  },
  {
    "id": 5,
    "ﬁrst_name": "Raymond",
    "last_name": "Moreno",
    "email": "rmoreno4@rakuten.co.jp",
    "gender": "Male"
  },
  {
    "id": 6,
    "ﬁrst_name": "Carolyn",
    "last_name": "Gray",
    "email": "cgray5@eepurl.com",
    "gender": "Female"
  },
  {
    "id": 7,
    "ﬁrst_name": "Gerald",
    "last_name": "Price",
    "email": "gprice6@reverbnation.com",
    "gender": "Male"
  },
  { "id": 8,
  "ﬁrst_name": "Gloria",
  "last_name": "Simpson",
  "email": "gsimpson7@example.com",
  "gender": "Female"
},
{
  "id": 9,
  "ﬁrst_name": "Harold",
  "last_name": "Kelly",
  "email": "hkelly8@reddit.com",
  "gender": "Male"
},
{ "id": 10,
"ﬁrst_name": "Lori",
"last_name": "Dean",
"email": "ldean9@hibu.com",
"gender": "Female"
},
{ "id": 11,
"ﬁrst_name": "Linda",
"last_name": "Mendoza",
"email": "lmendozaa@tuttocitta.it",
"gender": "Female"
},
{
  "id": 12,
  "ﬁrst_name": "Eric",
  "last_name": "Collins",
  "email": "ecollinsb@xrea.com",
  "gender": "Male"
},
{
  "id": 13,
  "ﬁrst_name": "Frank",
  "last_name": "Coleman",
  "email": "fcolemanc@drupal.org",
  "gender": "Male"
},
{
  "id": 14,
  "ﬁrst_name": "Doris",
  "last_name": "Banks",
  "email": "dbanksd@usa.gov",
  "gender": "Female"
},
{
  "id": 15,
  "ﬁrst_name": "Arthur",
  "last_name": "Green",
  "email": "agreene@addtoany.com",
  "gender": "Male"
}];

window.onload = function() {
  var dataStr = JSON.stringify(dataJson),
      dataArr = JSON.parse(dataStr),
      table = document.getElementById('table'),
      BtnSortDesc = document.getElementById('sort-descend'),
      BtnSortAsc = document.getElementById('sort-ascend'),
      insertName = document.getElementById('insertName'),
      filterByName = document.getElementById('filterByName'),
      tHead = "<tr><th>Name</th><th>E-mail</th><th>Gender</th></tr>";

  var imgArray = [
      'http://placehold.it/300x200/838eaf',
      'http://placehold.it/200x100/5b71b2',
      'http://placehold.it/400x300/404862',
      'http://placehold.it/400x300/23262d',
      'http://www.opinionleader.com.ua/wp-content/themes/FinalTestTheme/img/header_bckgr.jpg'],
      curIndex = 0,
      imgDuration = 6000,
      slider = document.getElementById('slider');

  function slideShow() {
      slider.className += "fadeOut";
      setTimeout(function() {
          slider.src = imgArray[curIndex];
          slider.className = "";
      },3000);
      curIndex++;
      if (curIndex == imgArray.length) { curIndex = 0; }
      setTimeout(slideShow, imgDuration);
  }
  slideShow();

  function renderTable (data) {
    for(var i = 0; i < data.length; i++) {
      table.insertAdjacentHTML("beforeEnd", "<tr id='table-row'><td>" + data[i].ﬁrst_name + ' ' + data[i].last_name + "</td><td>" + data[i].email + "</td><td>" + data[i].gender + "</td></tr>");
    };
  };

  renderTable (dataArr);

  filterByName.onclick = function() {
    table.innerHTML = tHead;
    var val = insertName.value;
    for(var i = 0; i < dataArr.length; i++) {
      if(dataArr[i].ﬁrst_name === val) {
        table.insertAdjacentHTML("beforeEnd", "<tr id='table-row'><td>" + dataArr[i].ﬁrst_name + ' ' + dataArr[i].last_name + "</td><td>" + dataArr[i].email + "</td><td>" + dataArr[i].gender + "</td></tr>");
      };
    };
    insertName.value = "";
  };

  BtnSortDesc.onclick = function() {
    table.innerHTML = tHead;
    var desc = function (field) {
      return function (x, y) {
        return x[field] < y[field];
      }
    };
    dataArr.sort(desc('ﬁrst_name'));
    for(var i = 0; i < dataArr.length; i++) {
      table.insertAdjacentHTML("beforeEnd", "<tr id='table-row'><td>" + dataArr[i].ﬁrst_name + dataArr[i].last_name + "</td><td>" + dataArr[i].email + "</td><td>" + dataArr[i].gender + "</td></tr>");
    };
  };

  BtnSortAsc.onclick = function() {
    table.innerHTML = tHead;
    var asc = function (field) {
      return function (x, y) {
        return x[field] > y[field];
      }
    };
    dataArr.sort(asc('ﬁrst_name'));
    for(var i = 0; i < dataArr.length; i++) {
      table.insertAdjacentHTML("beforeEnd", "<tr id='table-row'><td>" + dataArr[i].ﬁrst_name + dataArr[i].last_name + "</td><td>" + dataArr[i].email + "</td><td>" + dataArr[i].gender + "</td></tr>");
    };
  };
};
