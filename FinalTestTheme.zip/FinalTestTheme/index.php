<?php get_header(); ?>
  <main>
    <div class="main-container">
      <h1 class="main-head"><span><?php echo get_theme_mod('main_header1', 'Lorem: '); ?></span><?php echo get_theme_mod('main_header2', 'about the company'); ?></h1>
      <div class="main-box">
        <div class="col mission">
          <h2><?php echo get_theme_mod('main-col1-head', 'mission'); ?></h2>
          <p><?php echo get_theme_mod('main-col1-par', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque est excepturi magnam optio,quos, recusanda'); ?></p>
        </div>
        <div class="col vision">
          <h2><?php echo get_theme_mod('main-col2-head', 'vision'); ?></h2>
          <p><?php echo get_theme_mod('main-col2-par', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque est excepturi magnam optio, possimus quaerat quasi, quibusdam t quos, recusandae vel.'); ?></p>
        </div>
        <div class="col values">
          <h2><?php echo get_theme_mod('main-col3-head', 'values'); ?></h2>
          <p><?php echo get_theme_mod('main-col2-par', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque est excepturi'); ?></p>
        </div>
      </div>
    </div>
  </main>
<?php get_footer(); ?>
