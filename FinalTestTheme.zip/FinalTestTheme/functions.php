<?php
// подключение стилей
function enqueue_styles() {
	wp_register_style('font-style', 'https://fonts.googleapis.com/css?family=Lato:300,400,700|PT+Sans:400,700');
	wp_enqueue_style( 'font-style');
	wp_enqueue_style('style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'enqueue_styles');

// подключение скриптов
function enqueue_scripts() {
	wp_register_script('html5-shim',
	'http://html5shim.googlecode.com/svn/trunk/html5.js');
	wp_enqueue_script('html5-shim');
	wp_enqueue_script('script', get_template_directory_uri() . '/js/script.js');
}
add_action('wp_enqueue_scripts', 'enqueue_scripts');

// Header menu
register_nav_menu('menu', 'Header menu');

/**
 * Добавляет секции, параметры и элементы управления (контролы) на страницу настройки темы
 */
 // Секция редактирования хедера
add_action('customize_register', function($customizer){
    $customizer->add_section(
        'header_section_edit',
        array(
            'title' => 'Castomize Header content',
            'description' => 'Fill in fields with main&additional text needed to be displayed ',
            'priority' => 20,
        )
    );
    // param 1
    $customizer->add_setting(
      'header_slogan',
      array('default' => 'what you need to know')
    );
    $customizer->add_control(
      'header_slogan',
      array(
        'label' => 'Put slogan text below',
        'section' => 'header_section_edit',
        'type' => 'text',
      )
    );
   // param 2
   $customizer->add_setting(
     'left-col-subhead',
     array('default' => 'What’s in the lorem?')
   );
   $customizer->add_control(
     'left-col-subhead',
     array(
       'label' => 'Left column subheader',
       'section' => 'header_section_edit',
       'type' => 'text',
     )
   );
   // param 3
   $customizer->add_setting(
     'left-col-para1',
     array('default' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque est excepturi magnam optio, possimus quaerat quasi,')
   );
   $customizer->add_control(
     'left-col-para1',
     array(
        'label' => 'Left column paragraph 1',
        'section' => 'header_section_edit',
        'type' => 'text',
      )
    );
    // param 4
    $customizer->add_setting(
      'left-col-para2',
      array('default' => 'quibusdam recusandae rem repellendus rerum sapiente? Amet distinctio doloribus fugiat nesciunt quos, recusandae vel.')
    );
    $customizer->add_control(
      'left-col-para2',
      array(
        'label' => 'Left column paragraph 2',
        'section' => 'header_section_edit',
        'type' => 'text',
      )
    );
    // param 5
    $customizer->add_setting(
      'right-col-subhead',
      array('default' => 'Get your free copy')
    );
    $customizer->add_control(
      'right-col-subhead',
      array(
        'label' => 'Right column subheader',
        'section' => 'header_section_edit',
        'type' => 'text',
      )
    );
    // param 6
    $customizer->add_setting(
        'head-btn-text',
        array('default' => 'GET THE BOOK')
    );
    $customizer->add_control(
        'head-btn-text',
        array(
            'label' => 'Submit button text',
            'section' => 'header_section_edit',
            'type' => 'text',
        )
    );
});
// Секция редактирования в main главной страницы
add_action('customize_register', function($customizer){
	 $customizer->add_section(
			 'main_section_edit',
			 array(
					 'title' => 'Castomize home page info',
					 'description' => 'Edit description of main information',
					 'priority' => 30,
			 )
	 );
	 // param 1
	 $customizer->add_setting(
		 'main_header1',
		 array('default' => 'Lorem: ')
	 );
	 $customizer->add_control(
		 'main_header1',
		 array(
			 'label' => "First header part. It may me company's name",
			 'section' => 'main_section_edit',
			 'type' => 'text',
		 )
	 );
	// param 2
	$customizer->add_setting(
		'main_header2',
		array('default' => 'about the company')
	);
	$customizer->add_control(
		'main_header2',
		array(
			'label' => 'Second header part',
			'section' => 'main_section_edit',
			'type' => 'text',
		)
	);
	// param 3
	$customizer->add_setting(
		'main-col1-head',
		array('default' => 'mission')
	);
	$customizer->add_control(
		'main-col1-head',
		array(
			 'label' => 'Header of left column',
			 'section' => 'main_section_edit',
			 'type' => 'text',
		 )
	 );
	 // param 4
	 $customizer->add_setting(
		 'main-col1-par',
		 array('default' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque est excepturi magnam optio,quos, recusanda')
	 );
	 $customizer->add_control(
		 'main-col1-par',
		 array(
			 'label' => 'Left column paragraph',
			 'section' => 'main_section_edit',
			 'type' => 'text',
		 )
	 );
	 // param 5
	 $customizer->add_setting(
		 'main-col2-head',
		 array('default' => 'vision')
	 );
	 $customizer->add_control(
		 'main-col2-head',
		 array(
			 'label' => 'Center column header',
			 'section' => 'main_section_edit',
			 'type' => 'text',
		 )
	 );
	 // param 6
	 $customizer->add_setting(
			 'main-col2-par',
			 array('default' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque est excepturi magnam optio, possimus quaerat quasi, quibusdam t quos, recusandae vel.')
	 );
	 $customizer->add_control(
			 'main-col2-par',
			 array(
					 'label' => 'Center column paragraph',
					 'section' => 'main_section_edit',
					 'type' => 'text',
			 )
	 );
	 // param 7
	 $customizer->add_setting(
			 'main-col3-head',
			 array('default' => 'values')
	 );
	 $customizer->add_control(
			 'main-col3-head',
			 array(
					 'label' => 'Right column header',
					 'section' => 'main_section_edit',
					 'type' => 'text',
			 )
	 );
	 // param 8
	 $customizer->add_setting(
			 'main-col3-par',
			 array('default' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque est excepturi')
	 );
	 $customizer->add_control(
			 'main-col3-par',
			 array(
					 'label' => 'Right column paragraph',
					 'section' => 'main_section_edit',
					 'type' => 'text',
			 )
	 );
 });

	 // Секция редактирования футера
	add_action('customize_register', function($customizer){
	    $customizer->add_section(
	        'footer_section_edit',
	        array(
	            'title' => 'Castomize Footer elements',
	            'description' => 'Fill in fields with text to change footer elements data',
	            'priority' => 40,
	        )
	    );
	    // param 1
	    $customizer->add_setting(
	      'footer-btn',
	      array('default' => 'i want to read!')
	    );
	    $customizer->add_control(
	      'footer-btn',
	      array(
	        'label' => 'Footer button text',
	        'section' => 'footer_section_edit',
	        'type' => 'text',
	      )
	    );
	   // param 2
	   $customizer->add_setting(
	     'footer-text',
	     array('default' => 'Have questions?')
	   );
	   $customizer->add_control(
	     'footer-text',
	     array(
	       'label' => 'Text displayed before link',
	       'section' => 'footer_section_edit',
	       'type' => 'text',
	     )
	   );
	   // param 3
	   $customizer->add_setting(
	     'footer-link',
	     array('default' => 'Ask away')
	   );
	   $customizer->add_control(
	     'footer-link',
	     array(
	        'label' => 'Text to describe link',
	        'section' => 'footer_section_edit',
	        'type' => 'text',
	      )
	    );
	    // param 4
	    $customizer->add_setting(
	      'copyright',
	      array('default' => ' Lorem 2015')
	    );
	    $customizer->add_control(
	      'copyright',
	      array(
	        'label' => 'Copyright text',
	        'section' => 'footer_section_edit',
	        'type' => 'text',
	      )
	    );
	});
?>
