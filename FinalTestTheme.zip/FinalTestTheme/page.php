<?php get_header();?>
<?php if ( is_page('table') ) {
   get_template_part('table');
}?>
<?php get_footer(); ?>
