<?php get_header();
//
// Template Name: Table

?>
<section class="table-box">
  <table id="table">
    <tr>
      <th>Name</th>
      <th>E-mail</th>
      <th>Gender</th>
    </tr>
  </table>
  <button id="sort-descend">Sort by name descending</button>
  <button id="sort-ascend">Sort by name ascending</button>
  <form action="#" method="post">
        <input id="insertName" type="text" name="name" placeholder="Enter the first name">
        <input id="filterByName" type="button" name="filter" value="Filter">
  </form>
</section>
<?php get_footer(); ?>
